"""Services package for LocalShare."""
