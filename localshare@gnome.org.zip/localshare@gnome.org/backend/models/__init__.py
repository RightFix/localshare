"""Pydantic models for LocalShare."""
