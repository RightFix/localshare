"""Authentication module for LocalShare."""
