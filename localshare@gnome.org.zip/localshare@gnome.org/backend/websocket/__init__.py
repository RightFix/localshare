"""WebSocket handlers for LocalShare."""
